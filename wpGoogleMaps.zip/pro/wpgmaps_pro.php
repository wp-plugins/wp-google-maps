<?php
/*
Plugin Name: WP Google Maps Pro - Addon
Plugin URI: http://www.wpgmaps.com

 */


global $wpgmza_pro_version;
$wpgmza_pro_version = "2.0";
global $wpgmza_p;
$wpgmza_p = true;
global $wpgmza_t;
$wpgmza_t = "p";

function wpgmza_pro_menu() {
   global $wpgmza_pro_version;
   global $wpgmza_version;
   $wpgmza_data = get_option('WPGMZA');
   if (!$wpgmza_data['map_id'] || $wpgmza_data['map_id'] == "") { $wpgmza_data['map_id'] = 1; }

   if ($wpgmza_data['map_start_zoom']) { $wpgmza_zoom[$wpgmza_data['map_start_zoom']] = "SELECTED"; } else { $wpgmza_zoom[8] = "SELECTED"; }
    $wpgmza_csv = "<a href=\"".wpgmaps_get_plugin_url()."/csv.php\" title=\"Download this as a CSV file\">Download this data as a CSV file</a>";

    if (isset($wpgmza_pro_version)) {
        if ($wpgmza_pro_version != $wpgmza_version) { $version_message = "<div class='error below-h2'>There is a new (Pro) version of this plugin. An email containing a download link has been sent to the email address you used to make the original purchase.</div>"; }
    }


    echo "
       <div class='wrap'>
            <h2>WP Google Maps (Pro Edition)</h2>
            <div class='wide'>

                <h3>Create your map</h3>
                $version_message
                <p>Short code: <input type='text' name='shortcode' value='[wpgmza id=\"".$wpgmza_data['map_id']."\"]' /> <small><i>copy this into your post or page to display the map</i></p>
                <form action='' method='post' id='wpgmaps_options'>
                <p></p>

                    <input type='hidden' name='http_referer' value='".$_SERVER['PHP_SELF']."' />
                    <input type='hidden' name='wpgmza_id' id='wpgmza_id' value='".$wpgmza_data['map_id']."' />



                        <p>Width: <input id='wpgmza_width' name='wpgmza_width' type='text' size='4' maxlength='4' value='".$wpgmza_data['map_width']."' /> px &nbsp; &nbsp;
                        Height: <input id='wpgmza_height' name='wpgmza_height' type='text' size='4' maxlength='4' value='".$wpgmza_data['map_height']."' /> px</p>

                        <p>Starting Location: <input id='wpgmza_start_location' name='wpgmza_start_location' type='text' size='40' maxlength='100' value='".$wpgmza_data['map_start_location']."' /> <small><i>Examples: \"China\", \"London\", \"Boksburg\", \"25 Marine Parade Road, Durban\"</i></small></p>
                        <p>Zoom Level:
                        <select id='wpgmza_start_zoom' name='wpgmza_start_zoom'>
                            <option value=\"1\" ".$wpgmza_zoom[1].">1</option>
                            <option value=\"2\" ".$wpgmza_zoom[2].">2</option>
                            <option value=\"3\" ".$wpgmza_zoom[3].">3</option>
                            <option value=\"4\" ".$wpgmza_zoom[4].">4</option>
                            <option value=\"5\" ".$wpgmza_zoom[5].">5</option>
                            <option value=\"6\" ".$wpgmza_zoom[6].">6</option>
                            <option value=\"7\" ".$wpgmza_zoom[7].">7</option>
                            <option value=\"8\" ".$wpgmza_zoom[8].">8</option>
                            <option value=\"9\" ".$wpgmza_zoom[9].">9</option>
                            <option value=\"10\" ".$wpgmza_zoom[10].">10</option>
                            <option value=\"11\" ".$wpgmza_zoom[11].">11</option>
                            <option value=\"12\" ".$wpgmza_zoom[12].">12</option>
                            <option value=\"13\" ".$wpgmza_zoom[13].">13</option>
                            <option value=\"14\" ".$wpgmza_zoom[14].">14</option>
                            <option value=\"15\" ".$wpgmza_zoom[15].">15</option>
                            <option value=\"16\" ".$wpgmza_zoom[16].">16</option>
                            <option value=\"17\" ".$wpgmza_zoom[17].">17</option>
                            <option value=\"18\" ".$wpgmza_zoom[18].">18</option>
                            <option value=\"19\" ".$wpgmza_zoom[19].">19</option>
                            <option value=\"20\" ".$wpgmza_zoom[20].">20</option>
                            <option value=\"21\" ".$wpgmza_zoom[21].">21</option>
                        </select>

                        <p>Note: You can also change the starting location and zoom level using your mouse. When you have positioned the map to your desired location, press \"Save Map\" to keep your settings.</p>

                        <p class='submit'><input type='submit' name='wpgmza_savemap' value='Save Map &raquo;' /></p>


                        <div id=\"wpgmza_map\">&nbsp;</div>

                        <h4>Add a marker</h4>
                        <p>
                        <table>
                        <tr><td>Address: </td><td><input id='wpgmza_add_address' name='wpgmza_add_address' type='text' size='35' maxlength='200' value='' /> &nbsp;<br /></td></tr>

                        <tr><td>Description: </td><td><input id='wpgmza_add_desc' name='wpgmza_add_desc' type='text' size='35' maxlength='300' value='' ".$wpgmza_act."/>  &nbsp;<br /></td></tr>
                        <tr><td>Pic URL: </td><td><input id='wpgmza_add_pic' name=\"wpgmza_add_pic\" type='text' size='35' maxlength='700' value='' ".$wpgmza_act."/> <input id=\"upload_image_button\" type=\"button\" value=\"Upload Image\" $wpgmza_act /> &nbsp; <small><i>(Or paste image URL)</i></small><br /></td></tr>
                        <tr><td>Link URL: </td><td><input id='wpgmza_link_url' name='wpgmza_link_url' type='text' size='35' maxlength='700' value='' ".$wpgmza_act." /><small><i> Format: http://www.domain.com</i></small><br /></td></tr>

                        <tr><td></td><td><a href='javascript:void();' id='wpgmza_addmarker'><big>Add Marker &gt;&gt;</big></a><span id=\"wpgmza_addmarker_loading\" style=\"display:none;\">Adding...</span></p></td></tr>
                        </table>
                        <p>$wpgmza_act_msg</p>

                        <h4>Markers</h4>
                        <div id=\"wpgmza_marker_holder\">
                            ".wpgmza_return_marker_list()."
                        </div>
                        $wpgmza_csv
                </form>
            </div>
        </div>
    ";

}
function wpgmaps_action_callback_pro() {
        global $wpdb;
        global $wpgmza_tblname;
        $check = check_ajax_referer( 'wpgmza', 'security' );
        $table_name = $wpdb->prefix . "wpgmza";
        if ($check == 1) {

            if ($_POST['action'] == "add_marker") {
                  $gps = wpgmza_get_lat_long($_POST['address']);
                  $lat = $gps['lat'];
                  $lng = $gps['lng'];
                  $rows_affected = $wpdb->insert( $table_name, array( 'map_id' => $_POST['map_id'], 'address' => $_POST['address'], 'desc' => $_POST['desc'], 'pic' => $_POST['pic'], 'link' => $_POST['link'], 'lat' => $lat, 'lng' => $lng ) );
                   wpgmaps_update_xml_file();
                   echo wpgmza_return_marker_list();
            }
            if ($_POST['action'] == "delete_marker") {
                $marker_id = $_POST['marker_id'];
                $wpdb->query(
                        "
                        DELETE FROM $wpgmza_tblname
                        WHERE `id` = '$marker_id'
                        LIMIT 1
                        "
                );
                wpgmaps_update_xml_file();
                echo wpgmza_return_marker_list();

            }
        }

	die(); // this is required to return a proper result

}




function wpgmaps_user_javascript_pro() {
    $ajax_nonce = wp_create_nonce("wpgmza");
    $wpgmza_data = get_option('WPGMZA');
    $wpgmza_lat = $wpgmza_data['map_start_lat'];
    $wpgmza_lng = $wpgmza_data['map_start_lng'];
    $wpgmza_width = $wpgmza_data['map_width'];
    $wpgmza_height = $wpgmza_data['map_height'];
    $start_zoom = $wpgmza_data['map_start_zoom'];
    if ($start_zoom < 1 || !$start_zoom) { $start_zoom = 5; }
    if (!$wpgmza_lat || !$wpgmza_lng) { $wpgmza_lat = "51.5081290"; $wpgmza_lng = "-0.1280050"; }

    ?>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript" >
    jQuery(function() {


    jQuery("#wpgmza_map").css({
        height:<?php echo $wpgmza_height; ?>,
        width:<?php echo $wpgmza_width; ?>

    });
    var myLatLng = new google.maps.LatLng(<?php echo $wpgmza_lat; ?>,<?php echo $wpgmza_lng; ?>);
    MYMAP.init('#wpgmza_map', myLatLng, <?php echo $start_zoom; ?>);
    UniqueCode=Math.round(Math.random()*10000);
    MYMAP.placeMarkers('<?php echo wpgmaps_get_plugin_url(); ?>/markers.xml?u='+UniqueCode);


    });


    var MYMAP = {
        map: null,
        bounds: null
    }
    MYMAP.init = function(selector, latLng, zoom) {
      var myOptions = {
        zoom:zoom,
        center: latLng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.map = new google.maps.Map(jQuery(selector)[0], myOptions);
            this.bounds = new google.maps.LatLngBounds();
    }

    MYMAP.placeMarkers = function(filename) {
        jQuery.get(filename, function(xml){
                jQuery(xml).find("marker").each(function(){
                        var wpmgza_address = jQuery(this).find('address').text();
                        var wpmgza_mapicon = jQuery(this).find('icon').text();
                        var wpmgza_image = jQuery(this).find('pic').text();
                        var wpmgza_desc  = jQuery(this).find('desc').text();
                        var wpmgza_linkd = jQuery(this).find('linkd').text();

                        if (wpmgza_image != "") {
                            wpmgza_image = "<br /><img src='<?php echo wpgmaps_get_plugin_url(); ?>/timthumb.php?src="+wpmgza_image+"&h=100&w=100&zc=1' title='' alt='' style=\"float:right; margin:5px;\" />";
                        } else { wpmgza_image = "" }
                        if (wpmgza_linkd != "") {
                            wpmgza_linkd = "<a href='"+wpmgza_linkd+"' title=''>More details</a>";
                        }

                        var lat = jQuery(this).find('lat').text();
                        var lng = jQuery(this).find('lng').text();
                        var point = new google.maps.LatLng(parseFloat(lat),parseFloat(lng));
                        MYMAP.bounds.extend(point);
                        var marker = new google.maps.Marker({
                                position: point,
                                map: MYMAP.map

                        });
                        var infoWindow = new google.maps.InfoWindow();
                        var html=''+wpmgza_image+'<strong>'+wpmgza_address+'</strong><br /><span style="font-size:12px;">'+wpmgza_desc+'<br />'+wpmgza_linkd+'</span>';

                        google.maps.event.addListener(marker, 'click', function() {
                                infoWindow.setContent(html);
                                infoWindow.open(MYMAP.map, marker);
                        });

                });
        });
    }

    </script>
<?php

}



?>